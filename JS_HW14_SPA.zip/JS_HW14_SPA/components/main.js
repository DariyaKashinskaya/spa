import $ from './utilits.js'
import {getCookie} from '../cookie.js'
import {setCookie} from '../cookie.js'

class Main {
    constructor() {
        this.amountProduct = []
        this.buyProducts = localStorage.getItem('buyProduct') ? JSON.parse(localStorage.getItem('buyProduct')) : []
        this.fullPrice = localStorage.getItem('buyProduct') ? getCookie('fullPrice') : 0
    }
    createProductPage() {
        const main = document.createElement('div')
        main.classList.add('products-div')
        $('.products-head').insertAdjacentElement('afterend', main)
        $('.products-head').innerHTML = '<p>Products</p>'
        this.getProducts()
    }
    createProductCard(product){
        $('.products-div').insertAdjacentHTML('beforeend', `
        <div class ='product'>
            <div class ='product-image'>
                <img src='${product.image}'>
            </div>
            <div class ='product-information'>
                <h2>${product.title}</h2>
                <div class ='product-cart'>
                    <p class='price'>$${product.price}</p>
                    <img class='buy-button' src='images/cart.png'>
                </div>
            </div>
        </div>
        `)
    }
    
    getAmountBuyProduct(){
        const products = document.querySelectorAll('.product'); 
        const buttonForBuy = document.querySelectorAll('.buy-button'); 
        const productsImage = document.querySelectorAll('.product-image'); 
        const productsTitle = document.querySelectorAll('.product-information > h2'); 
        this.amountProduct = new Array(20);
        this.amountProduct.fill(1)
        for (let i = 0; i < products.length; i++) {
            products[i].addEventListener("mouseenter", () => {
                products[i].querySelector('.price').innerHTML = `
                <div class='main-minus'>-</div>
                <input type="number" class='amount${i}' value='${this.amountProduct[i]}'>
                <div class='main-plus'>+</div>
                `
                $('.main-minus').addEventListener('click', () => {
                    if ($('.price input').value > 0) $('.price input').value--
                })
                $('.main-plus').addEventListener('click', () => {
                    $('.price input').value++
                })
            }); 
            products[i].addEventListener("mouseleave", () => {
                this.amountProduct[i] = +$(`.amount${i}`).value
                products[i].querySelector('.price').innerHTML = '$' + JSON.parse(localStorage.getItem('products'))[i].price
            });
            productsTitle[i].addEventListener('click', () => window.location.hash = `product/${i+1}`)
            productsImage[i].addEventListener('click', () => window.location.hash = `product/${i+1}`)
            buttonForBuy[i].addEventListener('click', () => { 
                let buyObj = JSON.parse(localStorage.getItem('products'))[i]
                buyObj.amount = +$(`.amount${i}`).value 

                if (this.buyProducts.find(item => item.title === buyObj.title)) { 
                    let repeat = this.buyProducts.find(item => item.title === buyObj.title)
                    repeat.amount = +repeat.amount + +buyObj.amount
                } else {
                    this.buyProducts.push(buyObj) 
                }

                $('.amount-products-cart').innerHTML = this.buyProducts.length    
                console.log(this.fullPrice);            
                this.fullPrice += buyObj.amount * buyObj.price 
                console.log(this.fullPrice);            
                localStorage.setItem('buyProduct', JSON.stringify(this.buyProducts)) 
                setCookie('fullPrice', this.fullPrice)   
                $('.full-price-cart').innerHTML = '$' + Math.round(this.fullPrice*100)/100
                $(`.amount${i}`).value = 1 
                buttonForBuy[i].style.backgroundColor = 'grey'
                setTimeout(()=> {buttonForBuy[i].style.backgroundColor = 'bisque'}, 1000)
            })
        }
    }
    getProducts(){ 
        if (!localStorage.getItem('products')) {
            fetch('https://fakestoreapi.com/products')
            .then(response => response.json())
            .then(products => {
                localStorage.setItem('products', JSON.stringify(products))
                products.map(product => this.createProductCard(product))
                this.getAmountBuyProduct()
            })
        } else {
            JSON.parse(localStorage.getItem('products')).map(product => this.createProductCard(product))
            this.getAmountBuyProduct()
        }
    }
    sumHeadFullPrice() { 
        this.fullPrice = 0
        if (localStorage.getItem('buyProduct')) {
            JSON.parse(localStorage.getItem('buyProduct')).map(item => {
                this.fullPrice += item.amount * item.price
            })
            setCookie('fullPrice', this.fullPrice)
            $('.cart-link').innerHTML = `<img class='img-cart' src='images/cart.png'>
            <span class='amount-products-cart'>${JSON.parse(localStorage.getItem('buyProduct')).length}</span>
            <span class='full-price-cart'>$${+Math.round(this.fullPrice*100)/100}</span>`
        } else {
            $('.cart-link').innerHTML = `<img class='img-cart' src='images/cart.png'>
            <span class='amount-products-cart'>0</span>
            <span class='full-price-cart'>$0</span>`
        }
        
    }
    modalWindow(taskId) {
        const closeMethod = () => {
            modalContainer.classList.remove('show')
            setTimeout(() => {
                modalContainer.remove() 
            }, 500)
            window.location.hash = 'home'
        }
        const modalContainer = document.createElement('div')
        modalContainer.classList.add('modal-container')
        let main = JSON.parse(localStorage.getItem('products'))[taskId];
        console.log(main);
        modalContainer.innerHTML = `
            <div class="modal-block"> 
                <div class='close'></div>
                <div class ='modal-product'>
                    <div class ='modal-product-image'>
                        <img src='${main.image}'>
                    </div>
                    <div class ='product-information'>
                        <h2 class='modal-title'>${main.title}</h2>
                        <p class='description'>${main.description}</p>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modalContainer) 
        $('.close').addEventListener('click', closeMethod)
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') closeMethod()
        })
        setTimeout(() => {
            modalContainer.classList.add('show') 
        }, 100)
        
    }
    changeCartPage() { 
        let buyProductsPlus = document.querySelectorAll('.plus')
        let buyProductsMinus = document.querySelectorAll('.minus')
        let buyProductsFullPrice = document.querySelectorAll('.full-price')
        let buyProductsAmount = document.querySelectorAll('.change-amount-buy-products input')
        let deleteProducts = document.querySelectorAll('.delete-button')
        for (let i = 0; i < JSON.parse(localStorage.getItem('buyProduct')).length; i++) {
            buyProductsMinus[i].addEventListener('click', () => { 
                if (buyProductsAmount[i].value > 0) buyProductsAmount[i].value--
                buyProductsFullPrice[i].innerHTML = `$${+Math.round(buyProductsAmount[i].value * JSON.parse(localStorage.getItem('buyProduct'))[i].price * 100)/100}`
            })
            buyProductsPlus[i].addEventListener('click', () => { 
                buyProductsAmount[i].value++
                buyProductsFullPrice[i].innerHTML = `$${+Math.round(buyProductsAmount[i].value * JSON.parse(localStorage.getItem('buyProduct'))[i].price * 100)/100}`
            })
            deleteProducts[i].addEventListener('click', () => { 
                this.buyProducts.splice(i, 1)
                localStorage.setItem('buyProduct', JSON.stringify(this.buyProducts)) 
                $('.cart-div').remove()
                console.log(this.buyProducts);
                this.createCartPage()
                this.sumHeadFullPrice()
            })
        }
        $('.cart-div button').addEventListener('click', () => { 
            for (let i = 0; i < JSON.parse(localStorage.getItem('buyProduct')).length; i++) {
                this.buyProducts[i].amount = buyProductsAmount[i].value
            }
            this.buyProducts = this.buyProducts.filter(item => +item.amount !== 0)
            localStorage.setItem('buyProduct', JSON.stringify(this.buyProducts)) 
            $('.cart-div').remove()
            this.createCartPage()
            this.sumHeadFullPrice()
        })
        console.log(this.fullPrice);  
    }
    createCartPage() {
        const main = document.createElement('div')
        main.classList.add('cart-div')
        $('.products-head').insertAdjacentElement('afterend', main)
        $('.products-head').innerHTML = '<p>Cart</p>'
        main.innerHTML = `
            <div class='head-cart'>
                <p></p>
                <p>Product</p>
                <p></p>
                <p>Price</p>
                <p>Quantity</p>
                <p>Subtotal</p>
            </div>
        `
        this.buyProducts.map(item => $('.cart-div').insertAdjacentHTML('beforeend', `
            <div class='cart'>
                <div class='delete-button'></div>
                <img src='${item.image}'>
                <p class='cart-title'>${item.title}</p>
                <p>$${item.price}</p>
                <div class='change-amount-buy-products'>
                    <div class='minus'>-</div>
                    <input value='${item.amount}'>
                    <div class='plus'>+</div>
                </div>
                <p class='full-price'>$${+Math.round(item.amount * item.price * 100)/100}</p>
            </div>
        `))
        $('.cart-div').insertAdjacentHTML('beforeend', `
            <button>Update cart</button>
        `)
        this.changeCartPage()
    }
    createContactsPage() {
        const main = document.createElement('div')
        main.classList.add('contacts-div')
        $('.products-head').insertAdjacentElement('afterend', main)
        $('.products-head').innerHTML = '<p>Contacts</p>'
        main.innerHTML = `
            <div>
                <h1>Contact</h1>
                <a>59 Street, Newyork City, Rose Town, 05 Rive House</a>
                <a href='mailto:info@example.com'>Email: info@example.com</a>
                <a href='tel:+123 456 7890'>Tel: +123 456 7890</a>
            </div>
        `
    }
    init() {
        $('.pageHome').addEventListener('click', () => {
            window.location.hash = 'home'
        })
        $('.logo').addEventListener('click', () => {
            window.location.hash = 'home'
        })
        $('.pageContact').addEventListener('click', () => {
            window.location.hash = 'contacts'
        })
        $('.pageShop').addEventListener('click', () => {
            window.location.hash = 'home'
        })
        $('.cart-link').addEventListener('click', () => {
            window.location.hash = 'cart'
        })
        this.createProductPage()
    }
}
const main = new Main()
main.init()
const router = () => {
    const hash = window.location.hash

    if (hash.includes('contacts')) {
        main.createContactsPage()
    }
    if (hash.includes('home')) {
        main.createProductPage()
    }
    if (hash.includes('cart')) {
        main.createCartPage()
    }
    if (hash.includes('product')) {
        const id = hash.replace('#', '').replace('product/', '');
        main.modalWindow(+id-1)  
    }
}
window.addEventListener('hashchange', () => { 
    if (!(window.location.hash.includes('product'))) $('.products-head').nextElementSibling.remove() 
    router()
})
window.onload = () => { 
    let hash = window.location.hash
    if (hash) {
        $('.products-head').nextElementSibling.remove()
        router()
    } else {
        hash = 'home'
    }
}
export {main};