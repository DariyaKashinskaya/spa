const $ = (selector) => {
    return document.querySelector(selector)
}

export default $