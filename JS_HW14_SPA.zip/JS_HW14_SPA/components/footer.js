import $ from './utilits.js'
class Footer {
    create() {
        const footer = document.createElement('footer')
        $('.app').appendChild(footer)
        const logo = document.createElement('a')
        logo.setAttribute('href', '#')
        logo.innerHTML = `<img src='images/metro-black-logo.png'>`
        footer.insertAdjacentElement('beforeend', logo)
        const contacts = document.createElement('div')
        contacts.innerHTML = `
        <a>&#128205; 59 Street, Newyork City, Rose Town, 05 Rive House</a>
        <a href='mailto:info@example.com'>	
        &#128231; Email: info@example.com</a>
        <a href='tel:+123 456 7890'>&#9742; Tel: +123 456 7890</a>

        `

        footer.insertAdjacentElement('beforeend', contacts)
    }
    init() {
        this.create()
    }
}
const footer = new Footer().init()
export {footer};