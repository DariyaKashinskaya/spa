import $ from './utilits.js'
class App {
    constructor() {
        this.divA
    }
    create() {
        document.head.innerHTML = `
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="author" content="Dariya Kashinskaya">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>HW_js14_SPA</title>
            <link rel="stylesheet" href="style.css">
        `
        this.divA = document.createElement('div')
        this.divA.classList.add('app')
 
    }
    render() {
        document.body.appendChild(this.divA)
    }
    init() {
        this.create()
        this.render() 
    }
}
export default new App().init()
