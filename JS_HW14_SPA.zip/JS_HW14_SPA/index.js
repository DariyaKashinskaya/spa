import $ from './components/utilits.js'
import App from './components/app.js'
import {header} from './components/header.js'
import {nav} from './components/nav.js'
import {main} from './components/main.js'
import {footer} from './components/footer.js'
import {setCookie,getCookie} from './cookie.js'

